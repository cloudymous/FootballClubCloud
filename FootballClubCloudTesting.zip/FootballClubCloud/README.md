# Aplikasi Football Club
### Menggunakan API Response
Dalam aplikasi ini kita menggunakan API untuk menarik data dari internet dan menampilkannya kedalam aplikasi dengan menggunakan _RecyclerView_. Dalam project ini juga kita sudah menerapkan MVP untuk mengatur struktur project agar lebih terstruktur dan mudah dikembangkan kedepannya.
