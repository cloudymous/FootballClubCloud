package com.example.cloudymous.footballclubcloud.model

data class DetailMatchResponse(
    val events: List<DetailMatch>
)