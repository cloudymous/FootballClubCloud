package com.example.cloudymous.footballclubcloud.model

data class TeamResponse(
    val teams: List<Team>
)